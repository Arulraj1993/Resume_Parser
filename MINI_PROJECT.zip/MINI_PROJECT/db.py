# -*- coding: utf-8 -*-
"""
Created on Fri Feb 14 13:05:41 2020

@author: User
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Feb 13 21:11:59 2020

@author: ELCOT
"""
import sqlite3;
conn = sqlite3.connect('project.db')
cursor = conn.cursor()

#cursor.execute("DROP TABLE COMPANY")
#print("Table dropped... ")

#database creation
#companydb
import sqlite3;
conn = sqlite3.connect('project.db')
conn.execute('''CREATE TABLE COMPANY
         (NAME TEXT NOT NULL PRIMARY KEY,
         EMAIL TEXT NOT NULL,
         PASSWORD CHAR(20) NOT NULL);''')
           

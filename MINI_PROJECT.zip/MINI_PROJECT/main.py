import os
#import magic
from app import app
from flask import Flask, flash, request, redirect, render_template
from werkzeug.utils import secure_filename

ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'docx','doc'])

def allowed_file(filename):
	return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
	
@app.route('/')
def home_form():
	return render_template('home.html')
@app.route('/upload')
def upload_form():
    return render_template('upload.html')
@app.route('/login')
def login_form():
    return render_template('login.html')
@app.route('/register')
def register_form():
    return render_template('register.html')
@app.route('/result',methods = ['POST', 'GET'])
def result():
    if request.method == 'POST':
        result = request.form
        e=request.form.get("email")
        p1=request.form.get("pass")
        p2=request.form.get("pass1")
        print(e,p1,p2)
        if p1!=p2:
            error="Password Mismatched"
        else:
            import sqlite3
            conn = sqlite3.connect('project.db')
            cursor = conn.execute("SELECT NAME,EMAIL,PASSWORD from COMPANY")
            for row in cursor:
                if row[0]==p1:
                    break
            else:
                conn.execute("INSERT INTO COMPANY (NAME,EMAIL,PASSWORD) VALUES (?, ?, ?)",(e, e,p1))
                conn.commit()
                conn.close()
            return render_template("result.html",result = result)
    return render_template("register.html",error=error)


@app.route('/', methods=['POST'])
def upload_file():
	if request.method == 'POST':
        # check if the post request has the files part
		if 'files[]' not in request.files:
			flash('No file part')
			return redirect(request.url)
		files = request.files.getlist('files[]')
		for file in files:
			if file and allowed_file(file.filename):
				filename = secure_filename(file.filename)
				file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
		flash('File(s) successfully uploaded')
		return redirect('/')

if __name__ == "__main__":
    app.run()
    
if __name__ == "__main__":
    app.run()
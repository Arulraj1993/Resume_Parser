# -*- coding: utf-8 -*-
"""
Created on Thu Jan  9 12:53:26 2020

@author: User
"""
import PyPDF2 
import os
import docx2txt 
from nltk.corpus import stopwords 
from nltk.tokenize import line_tokenize 
entry=os.listdir('F:/SEMESTER4/MINI_PROJECT/pdf_to_text/Uploads')
#print(len(entry))
content=""
for e in entry:
    content=""
    filename='F:/SEMESTER4/MINI_PROJECT/pdf_to_text/Uploads/'+e
    name, ext = os.path.splitext(e)
    if(ext==".pdf"):
        pdfFileObj = open(filename, 'rb') 
        pdfReader = PyPDF2.PdfFileReader(pdfFileObj) 
        x=pdfReader.numPages 
        for i in range(0,x):
            pageObj = pdfReader.getPage(i) 
            ans=pageObj.extractText()
            content=content+ans
    if(ext==".txt"):
        tfobj=open(filename,'r')
        content=tfobj.read()
    if(ext==".docx"):
        content = docx2txt.process(filename)
        
    import nltk
    nltk.download('stopwords')
    nltk.download('punkt') 
    stop_words = set(stopwords.words('english')) 
    stop_words.add(".")
    stop_words.add(",")
    stop_words.add(":")
    stop_words.add("&")
    
    #print("Stop words=",stop_words)
    #print("\n\n")
    word_tokens =line_tokenize(content) 
    #print("Tokenized words=",word_tokens)
    filtered_sentence = [] 
    for w in word_tokens: 
        if w not in stop_words and w not in filtered_sentence: 
            filtered_sentence.append(w) 
    #print("\n After removing stop words",filtered_sentence)
    
    
    import nltk
    nltk.download('punkt')
    nltk.download('averaged_perceptron_tagger')
    nltk.download('maxent_ne_chunker')
    nltk.download('words')
    from nameparser.parser import HumanName

    def get_human_names(text):
        tokens = nltk.tokenize.word_tokenize(text)
        pos = nltk.pos_tag(tokens)
        sentt = nltk.ne_chunk(pos, binary = False)
        person_list = []
        person = []
        name = ""
        for subtree in sentt.subtrees(filter=lambda t: t.label() == 'PERSON'):
            for leaf in subtree.leaves():
                person.append(leaf[0])
            if len(person) > 1: #avoid grabbing lone surnames
                for part in person:
                    name += part + ' '
                if name[:-1] not in person_list:
                    person_list.append(name[:-1])
                name = ''
            person = []
        return (person_list)
       
    names=get_human_names(content)
    
    #print(content)
        
    import re
    education=[]
    EDUCATION = ['Bachelor of Science','BE','Bachelor of Engineering','B.E.','B.E','BS','B.S','ME', 'M.E', 'M.E.',
             'MS','M.S','Master of Science','BTECH','B.TECH','Bachelor of Technology','M.TECH','MTECH', 
            'SSLC','Higher Secondary Education','HSC', 'CBSE', 'ICSE']
    for i in range(0,len(EDUCATION)):
        if EDUCATION[i] in filtered_sentence:
            education.append(EDUCATION[i])
            break;
    print(filtered_sentence)
    
    #extracting skills
    skills=[]
    SKILLS = ['C','C++','JAVA','R','BASIC','SAP','ORACLE','LISP','PYTHON','PASCAL','PERL','JAVASCRIPT','RUPY','C#','COBOL','MATLAB','HTML','XML','PHP','ANDROID'
              'CSS','UI','UX','UI/UX','SQL','MYSQL','UNIX']
    for i in range(0,len(SKILLS)):
        if SKILLS[i] in filtered_sentence:
            skills.append(SKILLS[i])
            break;

    #extracting phone number
    phone=re.findall(r"[6-9][0-9]{9}",content)
    if phone:
           print(phone)

    #extracting email        
    email = re.findall("[A-Za-z0-9._%+-]+@[A-Za-z]+\.[A-Za-z]{2,}",content)
    if email:
        print(email)

    #create python dictionary of fetched details
    mydict={}
    mydict["NAME"]=names
    mydict["SKILLS"]=skills
    mydict["EDUCATION"]=education
    mydict["PHONE"]=phone
    mydict["EMAIL"]=email
    
    #import json
    import json
    jsonObj=json.dumps(mydict)
    print(jsonObj)